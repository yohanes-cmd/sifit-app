<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'type',
        'image',
    ];

    // Relasi: Satu Kategori bisa memiliki banyak Produk
    public function products()
    {
        return $this->hasMany(Product::class);
    }

    // Relasi: Satu Kategori bisa memiliki banyak Berita
    public function news()
    {
        return $this->hasMany(News::class);
    }
}
